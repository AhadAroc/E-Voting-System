export const imagePaths = {
  sampleQrCode: {
    local: "C:\\My Web Sites\\vote website\\Untitled 1.png", // Local path for reference
    web: "/Untitled1.png", // Ensure the file is placed in the website's public/static folder
  },
  solanaLogo: {
    local: "C:\\path\\to\\solana-logo.svg", // Replace with the actual path
    web: "/solana-logo.svg",
  },
};

