export function About() {
  return (
    <section id="about" className="py-20 bg-black/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-center mb-8">About Solana Secure Voting</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Secure and Transparent</h3>
            <p className="text-gray-300">
              Our blockchain-based voting system ensures the highest level of security and transparency.
              Every vote is recorded on the Solana blockchain, making it immutable and verifiable.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Fast and Efficient</h3>
            <p className="text-gray-300">
              Leveraging Solana's high-speed blockchain, our voting system can handle thousands of votes per second,
              ensuring a smooth and efficient voting process for even the largest elections.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

