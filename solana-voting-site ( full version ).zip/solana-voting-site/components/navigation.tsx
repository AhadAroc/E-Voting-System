import Link from 'next/link'
import Image from 'next/image'
import { SolanaButton } from './ui/solana-button'
import { useEffect } from 'react'

export function Navigation() {
  useEffect(() => {
    const smoothScroll = (e: Event) => {
      e.preventDefault();
      const target = e.target as HTMLAnchorElement;
      const id = target.getAttribute('href')?.slice(1);
      if (id) {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }
      }
    };

    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
      link.addEventListener('click', smoothScroll);
    });

    return () => {
      links.forEach(link => {
        link.removeEventListener('click', smoothScroll);
      });
    };
  }, []);

  return (
    <nav className="bg-black/30 backdrop-blur-md fixed w-full z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <Image 
                src="https://cryptologos.cc/logos/solana-sol-logo.png"
                alt="Solana" 
                width={32} 
                height={32} 
              />
            </Link>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link href="#about" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">About</Link>
                <Link href="#candidates" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Candidates</Link>
                <Link href="#how-it-works" className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium">How It Works</Link>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <SolanaButton href="/login">Connect Wallet</SolanaButton>
          </div>
        </div>
      </div>
    </nav>
  )
}

