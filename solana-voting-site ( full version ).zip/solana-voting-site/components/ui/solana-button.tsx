import { ButtonHTMLAttributes, forwardRef } from 'react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

interface SolanaButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary'
  href?: string
}

const SolanaButton = forwardRef<HTMLButtonElement, SolanaButtonProps>(
  ({ className, variant = 'primary', href, ...props }, ref) => {
    const ButtonComponent = href ? Link : 'button'
    return (
      <ButtonComponent
        className={cn(
          'inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none',
          variant === 'primary'
            ? 'bg-gradient-to-r from-purple-600 to-green-400 text-white hover:from-purple-700 hover:to-green-500'
            : 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
          className
        )}
        ref={ref}
        {...(href ? { href } : props)}
      />
    )
  }
)
SolanaButton.displayName = 'SolanaButton'

export { SolanaButton }

