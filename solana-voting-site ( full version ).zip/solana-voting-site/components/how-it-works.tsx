export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 bg-black/20 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-center mb-8">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-purple-600/70 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold">1</span>
            </div>
            <h3 className="text-xl font-semibold mb-2">Scan QR Code</h3>
            <p className="text-gray-300">Use your official voting QR code to securely log in to the system.</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-600/70 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold">2</span>
            </div>
            <h3 className="text-xl font-semibold mb-2">Cast Your Vote</h3>
            <p className="text-gray-300">Select your preferred candidate and submit your vote securely on the blockchain.</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-600/70 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold">3</span>
            </div>
            <h3 className="text-xl font-semibold mb-2">Verify Your Vote</h3>
            <p className="text-gray-300">Check the blockchain to confirm your vote has been recorded accurately.</p>
          </div>
        </div>
      </div>
    </section>
  )
}

