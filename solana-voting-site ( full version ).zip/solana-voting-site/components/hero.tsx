'use client'

import { useState } from 'react'
import Image from 'next/image'
import { QrReader } from 'react-qr-reader'
import { SolanaButton } from './ui/solana-button'
import { imagePaths } from '@/utils/imagePaths'

export function Hero() {
  const [data, setData] = useState('')
  const [isScanning, setIsScanning] = useState(false)

  const handleScan = (result: any) => {
    if (result) {
      setData(result?.text)
      setIsScanning(false)
      // Handle login logic here with the QR data
      console.log('QR Code scanned:', result.text)
    }
  }

  const handleError = (error: any) => {
    console.error(error)
  }

  return (
    <section className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold">
            Secure Blockchain Voting
          </h2>
          <p className="mt-2 text-center text-sm text-gray-300">
            Powered by Solana
          </p>
        </div>
        <div className="mt-8 space-y-6">
          <div className="flex flex-col items-center space-y-4">
            {isScanning ? (
              <div className="w-full max-w-[300px] aspect-square overflow-hidden rounded-lg">
                <QrReader
                  constraints={{ facingMode: 'environment' }}
                  onResult={handleScan}
                  className="w-full h-full"
                />
              </div>
            ) : (
              <>
                <div className="relative w-48 h-48 mb-4">
                  <Image 
                    src="https://i.ibb.co/GQ18g05/qr-code.png"
                    alt="Sample QR Code" 
                    width={192}
                    height={192}
                    objectFit="contain"
                  />
                </div>
                <p className="text-center text-sm text-gray-300 mb-4">
                  Scan your official voting QR code to login
                </p>
              </>
            )}
            <SolanaButton
              onClick={() => setIsScanning(!isScanning)}
              className="w-full max-w-[300px]"
            >
              {isScanning ? 'Cancel Scan' : 'Scan QR Code'}
            </SolanaButton>
          </div>
          {data && (
            <div className="text-center text-sm text-green-400">
              QR Code scanned successfully! Verifying credentials...
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

