import Image from 'next/image'

const candidates = [
  { name: 'Jane Doe', party: 'Progressive Party', image: '/jane-doe.jpg' },
  { name: 'John Smith', party: 'Conservative Party', image: '/john-smith.jpg' },
  { name: 'Alice Johnson', party: 'Centrist Alliance', image: '/alice-johnson.jpg' },
]

export function Candidates() {
  return (
    <section id="candidates" className="py-20 bg-black/10 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-center mb-8">Candidates</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {candidates.map((candidate) => (
            <div key={candidate.name} className="bg-white/20 backdrop-blur-md rounded-lg p-6 text-center">
              <div className="relative w-32 h-32 mx-auto mb-4">
                <Image
                  src={C:\website\public\Qr.png}
                  alt={candidate.name}
                  layout="fill"
                  objectFit="cover"
                  className="rounded-full"
                />
              </div>
              <h3 className="text-xl font-semibold">{candidate.name}</h3>
              <p className="text-gray-300">{candidate.party}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

