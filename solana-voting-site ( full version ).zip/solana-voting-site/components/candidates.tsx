const candidates = [
  { name: 'Jane Doe', party: 'Progressive Party', image: '/placeholder.svg?height=100&width=100' },
  { name: 'John Smith', party: 'Conservative Party', image: '/placeholder.svg?height=100&width=100' },
  { name: 'Alice Johnson', party: 'Centrist Alliance', image: '/placeholder.svg?height=100&width=100' },
]

export function Candidates() {
  return (
    <section id="candidates" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-center mb-8">Candidates</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {candidates.map((candidate) => (
            <div key={candidate.name} className="bg-white/10 backdrop-blur-md rounded-lg p-6 text-center">
              <img src={candidate.image} alt={candidate.name} className="w-32 h-32 rounded-full mx-auto mb-4" />
              <h3 className="text-xl font-semibold">{candidate.name}</h3>
              <p className="text-gray-300">{candidate.party}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

