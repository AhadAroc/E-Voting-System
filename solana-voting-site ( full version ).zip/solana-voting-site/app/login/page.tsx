import { SolanaButton } from '@/components/ui/solana-button'
import Link from 'next/link'

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 to-green-900">
      <div className="bg-white/10 backdrop-blur-md p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 className="text-3xl font-bold text-center text-white mb-6">Connect Your Wallet</h2>
        <div className="space-y-4">
          <SolanaButton className="w-full">Connect with Phantom</SolanaButton>
          <SolanaButton className="w-full">Connect with Solflare</SolanaButton>
          <SolanaButton className="w-full">Connect with Sollet</SolanaButton>
        </div>
        <div className="mt-6 text-center">
          <Link href="/" className="text-sm text-gray-300 hover:text-white">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}

