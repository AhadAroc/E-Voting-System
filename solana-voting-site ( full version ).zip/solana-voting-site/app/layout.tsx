import './globals.css'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Solana Secure Voting',
  description: 'A modern, blockchain-based voting platform',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-hue-shift`}>
        <div className="fixed inset-0 bg-gradient-to-br from-purple-900 to-green-900 opacity-75 z-[-1]" />
        <div className="relative z-0">
          {children}
        </div>
      </body>
    </html>
  )
}

