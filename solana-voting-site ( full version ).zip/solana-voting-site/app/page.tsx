import { Navigation } from '@/components/navigation'
import { Hero } from '@/components/hero'
import { About } from '@/components/about'
import { Candidates } from '@/components/candidates'
import { HowItWorks } from '@/components/how-it-works'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <main>
      <Navigation />
      <Hero />
      <About />
      <Candidates />
      <HowItWorks />
      <Footer />
    </main>
  )
}

